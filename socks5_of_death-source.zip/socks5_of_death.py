from __future__ import annotations

import sys
import os
import re
import time
import socket
import csv
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from datetime import datetime

import requests
import urllib3
from bs4 import BeautifulSoup

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtGui import QColor, QFont, QPainter, QPixmap, QIcon, QBrush
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QTableWidget, QTableWidgetItem, QLabel,
    QSplashScreen, QLineEdit, QProgressBar, QHeaderView, QFileDialog,
    QMessageBox, QFrame, QAbstractItemView, QSpinBox, QMenu,
    QPlainTextEdit, QSplitter, QDialog, QCheckBox,
    QDialogButtonBox, QScrollArea
)

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ── Windows taskbar AppUserModelID ────────────────────────────────────────────
try:
    import ctypes
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
        "DeathsHeadSoftware.SOCKS5ofDeath.1.0"
    )
except Exception:
    pass

# ── Linux XCB fix ─────────────────────────────────────────────────────────────
if sys.platform.startswith("linux"):
    os.environ.setdefault("QT_QPA_PLATFORM", "xcb")

# ── Constants ─────────────────────────────────────────────────────────────────
APP_NAME = "SOCKS5 of Death"
ORG_NAME = "Death's Head Software"
VERSION  = "1.0.0"

# ── Colours ───────────────────────────────────────────────────────────────────
BG_DARK    = "#0d0d0d"
BG_PANEL   = "#1a1a1a"
BG_TABLE   = "#111111"
ACCENT     = "#cc0000"
ACCENT_HOV = "#ff2222"
TEXT_PRI   = "#ffffff"
TEXT_SEC   = "#888888"
BORDER     = "#2a2a2a"
CLR_UP     = "#00cc44"
CLR_DOWN   = "#cc2222"
CLR_TEST   = "#ffaa00"
CLR_UNKWN  = "#666666"

# ── Table columns ─────────────────────────────────────────────────────────────
COL_IP      = 0
COL_PORT    = 1
COL_COUNTRY = 2
COL_SOURCE  = 3
COL_STATUS  = 4
COL_LATENCY = 5
NUM_COLS    = 6
COL_HEADERS = ["IP Address", "Port", "Country", "Source", "Status", "Latency (ms)"]

# ── Proxy sources ─────────────────────────────────────────────────────────────
SOURCES = [
    {"name": "ProxyScrape",    "url": "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=10000&country=all&simplified=true"},
    {"name": "TheSpeedX",      "url": "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt"},
    {"name": "proxifly",       "url": "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/socks5/data.txt"},
    {"name": "roosterkid",     "url": "https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS5_RAW.txt"},
    {"name": "ErcinDedeoglu",  "url": "https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/socks5.txt"},
    {"name": "monosans",       "url": "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt"},
    {"name": "officialputuid", "url": "https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/socks5/socks5.txt"},
    {"name": "hookzof",        "url": "https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt"},
    {"name": "ShiftyTR",       "url": "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks5.txt"},
    {"name": "proxy-list.dl",  "url": "https://www.proxy-list.download/api/v1/get?type=socks5"},
]

IP_PORT_RE = re.compile(r"(\d{1,3}(?:\.\d{1,3}){3}):(\d{2,5})")

# ─────────────────────────────────────────────────────────────────────────────
#  Helpers
# ─────────────────────────────────────────────────────────────────────────────

def resource_path(filename: str) -> Path:
    try:
        base = Path(sys._MEIPASS)           # type: ignore[attr-defined]
    except AttributeError:
        base = Path(__file__).parent
    return base / filename


def load_app_icon() -> QIcon:
    for name in ("icon.ico", "skull.png"):
        p = resource_path(name)
        if p.exists():
            return QIcon(str(p))
    return QIcon()


def _fix_sudo_display():
    if sys.platform.startswith("linux") and os.geteuid() == 0:
        os.environ["DISPLAY"]    = os.environ.get("DISPLAY", ":0")
        os.environ["XAUTHORITY"] = os.environ.get("XAUTHORITY", "")


def test_socks5(host: str, port: int, timeout: float = 6.0):
    """Real SOCKS5 handshake + CONNECT to 8.8.8.8:53. Returns (ok, ms)."""
    t0 = time.monotonic()
    try:
        with socket.create_connection((host, port), timeout=timeout) as s:
            s.sendall(b"\x05\x01\x00")
            resp = s.recv(2)
            if len(resp) < 2 or resp[0] != 0x05 or resp[1] != 0x00:
                return False, -1
            s.sendall(b"\x05\x01\x00\x01" + socket.inet_aton("8.8.8.8") + (53).to_bytes(2, "big"))
            resp = s.recv(10)
            if len(resp) >= 2 and resp[1] == 0x00:
                return True, int((time.monotonic() - t0) * 1000)
            return False, -1
    except Exception:
        return False, -1


# ─────────────────────────────────────────────────────────────────────────────
#  Splash  —  verbatim from uploaded splash_screen.py  (only APP_NAME changed)
# ─────────────────────────────────────────────────────────────────────────────

def create_splash():
    try:
        splash_path = Path(__file__).parent / "splash.png"

        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(800, 600,
                                       Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect()
            text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect,
                             Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
                             APP_NAME)
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect()
            footer_rect.setTop(pixmap.height() - 100)
            footer_rect.setBottom(pixmap.height() - 50)
            painter.drawText(footer_rect,
                             Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
                             ORG_NAME)
            painter.end()
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect()
            text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect,
                             Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
                             APP_NAME)
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y_start = 250
            for i, line in enumerate(skull_art):
                painter.drawText(250, y_start + (i * 25), line)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect()
            footer_rect.setTop(pixmap.height() - 50)
            footer_rect.setBottom(pixmap.height())
            painter.drawText(footer_rect,
                             Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
                             ORG_NAME)
            painter.end()

        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None


# ─────────────────────────────────────────────────────────────────────────────
#  Workers
# ─────────────────────────────────────────────────────────────────────────────

class ScraperWorker(QThread):
    proxy_found  = pyqtSignal(str, str, str, str)   # ip, port, country, source
    source_done  = pyqtSignal(str, int)
    log          = pyqtSignal(str)
    finished_all = pyqtSignal(int)

    def __init__(self, sources, parent=None):
        super().__init__(parent)
        self._sources = sources
        self._stop = threading.Event()

    def stop(self): self._stop.set()

    def run(self):
        seen:  set[str] = set()
        total: int      = 0
        session = requests.Session()
        session.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
            )
        })

        for src in self._sources:
            if self._stop.is_set():
                break
            name  = src["name"]
            found = 0
            self.log.emit(f"[→] {name} …")
            try:
                resp = session.get(src["url"], timeout=20, verify=False)
                resp.raise_for_status()
                text = resp.text
                self.log.emit(f"[✓] {name}: {len(text):,} bytes")

                for m in IP_PORT_RE.finditer(text):
                    if self._stop.is_set():
                        break
                    key = f"{m.group(1)}:{m.group(2)}"
                    if key not in seen:
                        seen.add(key)
                        self.proxy_found.emit(m.group(1), m.group(2), "—", name)
                        found += 1

            except Exception as e:
                self.log.emit(f"[✗] {name}: {e}")

            total += found
            self.log.emit(f"[■] {name}: {found} proxies")
            self.source_done.emit(name, found)

        self.finished_all.emit(total)


class TesterWorker(QThread):
    result   = pyqtSignal(str, str, bool, int)
    progress = pyqtSignal(int, int)
    finished = pyqtSignal()

    def __init__(self, proxies, threads=50, parent=None):
        super().__init__(parent)
        self._proxies = proxies
        self._threads = threads
        self._stop    = threading.Event()

    def stop(self): self._stop.set()

    def run(self):
        done = 0
        with ThreadPoolExecutor(max_workers=self._threads) as pool:
            futures = {pool.submit(test_socks5, ip, int(port)): (ip, port)
                       for ip, port in self._proxies}
            for fut in as_completed(futures):
                if self._stop.is_set():
                    pool.shutdown(wait=False, cancel_futures=True)
                    break
                ip, port = futures[fut]
                try:    ok, ms = fut.result()
                except: ok, ms = False, -1
                self.result.emit(ip, port, ok, ms)
                done += 1
                self.progress.emit(done, len(self._proxies))
        self.finished.emit()


# ─────────────────────────────────────────────────────────────────────────────
#  UI helpers
# ─────────────────────────────────────────────────────────────────────────────

def _btn(text, color=ACCENT, w=130):
    b = QPushButton(text)
    b.setFixedHeight(34); b.setMinimumWidth(w)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    b.setFont(QFont("Courier", 10, QFont.Weight.Bold))
    b.setStyleSheet(f"""
        QPushButton           {{ background:{color}; color:#fff; border:none;
                                 border-radius:4px; padding:0 14px; }}
        QPushButton:hover     {{ background:{ACCENT_HOV}; }}
        QPushButton:pressed   {{ background:#990000; }}
        QPushButton:disabled  {{ background:#2a2a2a; color:#555; }}
    """)
    return b

def _hsep():
    f = QFrame(); f.setFrameShape(QFrame.Shape.HLine)
    f.setStyleSheet(f"color:{BORDER};"); return f

def _vsep():
    f = QFrame(); f.setFrameShape(QFrame.Shape.VLine)
    f.setStyleSheet(f"color:{BORDER};"); return f


# ─────────────────────────────────────────────────────────────────────────────
#  Main window
# ─────────────────────────────────────────────────────────────────────────────

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME}  •  {ORG_NAME}")
        self.setMinimumSize(1100, 720)
        self.resize(1300, 820)
        self.setWindowIcon(load_app_icon())
        self._row_map: dict[str, int] = {}
        self._scraper: ScraperWorker | None = None
        self._tester:  TesterWorker  | None = None
        self._src_done  = 0
        self._cnt_up    = 0     # maintained incrementally — no O(n) scans
        self._cnt_down  = 0
        self._result_queue: list[tuple] = []
        self._enabled_sources: set[str] = {s["name"] for s in SOURCES}
        self._flush_timer = QTimer(self)
        self._flush_timer.setInterval(200)          # flush every 200 ms
        self._flush_timer.timeout.connect(self._flush_results)
        self._apply_style()
        self._build_ui()
        self._build_menu()

    # ── stylesheet ────────────────────────────────────────────────────────────

    def _apply_style(self):
        self.setStyleSheet(f"""
            QMainWindow, QWidget {{
                background:{BG_DARK}; color:{TEXT_PRI};
                font-family:'Courier New',Courier,monospace;
            }}
            QLabel {{ color:{TEXT_PRI}; }}
            QLineEdit, QSpinBox {{
                background:{BG_PANEL}; color:{TEXT_PRI};
                border:1px solid {BORDER}; border-radius:4px;
                padding:4px 8px; font-size:11px;
                font-family:'Courier New',Courier,monospace;
            }}
            QLineEdit:focus, QSpinBox:focus {{ border-color:{ACCENT}; }}
            QTableWidget {{
                background:{BG_TABLE}; color:{TEXT_PRI}; border:none;
                gridline-color:{BORDER}; font-size:11px;
                selection-background-color:#2a0000; selection-color:#fff;
                alternate-background-color:#141414;
            }}
            QTableWidget::item {{ padding:2px 6px; }}
            QHeaderView::section {{
                background:{BG_PANEL}; color:{TEXT_PRI}; border:none;
                border-bottom:1px solid {BORDER}; border-right:1px solid {BORDER};
                padding:6px 8px; font-weight:bold; font-size:11px;
                font-family:'Courier New',Courier,monospace;
            }}
            QPlainTextEdit {{
                background:#080808; color:#00cc44; border:none;
                font-family:'Courier New',Courier,monospace; font-size:10px;
            }}
            QScrollBar:vertical {{
                background:{BG_PANEL}; width:10px; border-radius:5px;
            }}
            QScrollBar::handle:vertical {{
                background:#3a0000; border-radius:5px; min-height:30px;
            }}
            QScrollBar::handle:vertical:hover {{ background:{ACCENT}; }}
            QScrollBar:horizontal {{
                background:{BG_PANEL}; height:10px; border-radius:5px;
            }}
            QScrollBar::handle:horizontal {{
                background:#3a0000; border-radius:5px;
            }}
            QScrollBar::add-line,QScrollBar::sub-line {{ width:0; height:0; }}
            QProgressBar {{
                background:{BG_PANEL}; border:1px solid {BORDER};
                border-radius:4px; text-align:center;
                color:{TEXT_PRI}; font-size:10px;
            }}
            QProgressBar::chunk {{ background:{ACCENT}; border-radius:3px; }}
            QMenuBar {{
                background:{BG_PANEL}; color:{TEXT_PRI};
                border-bottom:1px solid {BORDER}; font-size:11px;
            }}
            QMenuBar::item:selected {{ background:{ACCENT}; }}
            QMenu {{
                background:{BG_PANEL}; color:{TEXT_PRI};
                border:1px solid {BORDER}; font-size:11px;
            }}
            QMenu::item:selected {{ background:{ACCENT}; }}
            QSplitter::handle {{ background:{BORDER}; }}
            QToolTip {{
                background:{BG_PANEL}; color:{TEXT_PRI};
                border:1px solid {ACCENT}; font-size:11px;
            }}
        """)

    # ── layout ────────────────────────────────────────────────────────────────

    def _build_ui(self):
        c = QWidget(); self.setCentralWidget(c)
        root = QVBoxLayout(c); root.setContentsMargins(0,0,0,0); root.setSpacing(0)
        root.addWidget(self._mk_header())
        root.addWidget(_hsep())
        root.addWidget(self._mk_toolbar())
        root.addWidget(_hsep())
        sp = QSplitter(Qt.Orientation.Vertical)
        sp.addWidget(self._mk_table())
        sp.addWidget(self._mk_log())
        sp.setSizes([600, 120]); sp.setHandleWidth(4)
        root.addWidget(sp, stretch=1)
        root.addWidget(_hsep())
        root.addWidget(self._mk_progress())
        root.addWidget(self._mk_statusbar())

    def _mk_header(self):
        w = QWidget(); w.setFixedHeight(56)
        w.setStyleSheet(f"background:{BG_PANEL};")
        lay = QHBoxLayout(w); lay.setContentsMargins(18,0,18,0)
        p = resource_path("skull.png")
        if p.exists():
            lbl = QLabel()
            lbl.setPixmap(QPixmap(str(p)).scaled(36,36,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation))
            lay.addWidget(lbl)
        t = QLabel(APP_NAME); t.setFont(QFont("Courier New",20,QFont.Weight.Bold))
        t.setStyleSheet("margin-left:10px;"); lay.addWidget(t)
        lay.addStretch()
        o = QLabel(ORG_NAME); o.setFont(QFont("Courier New",11))
        lay.addWidget(o); return w

    def _mk_toolbar(self):
        w = QWidget(); w.setFixedHeight(56)
        w.setStyleSheet(f"background:{BG_PANEL};")
        lay = QHBoxLayout(w); lay.setContentsMargins(14,0,14,0); lay.setSpacing(8)

        self.btn_scrape   = _btn("⬇  SCRAPE",   ACCENT,    130)
        self.btn_sources  = _btn("⚙ SOURCES",   "#333333", 110)
        self.btn_test     = _btn("⚡ TEST ALL",  "#5a0000", 130)
        self.btn_test_sel = _btn("⚡ TEST SEL",  "#5a0000", 120)
        self.btn_stop     = _btn("■  STOP",      "#3a3a3a", 100)
        self.btn_clear    = _btn("✕  CLEAR",     "#2a2a2a", 100)
        self.btn_stop.setEnabled(False)

        self.btn_scrape.setToolTip("Scrape SOCKS5 proxies from selected sources")
        self.btn_sources.setToolTip("Choose which sources to scrape")
        self.btn_test.setToolTip("Test every proxy in the list")
        self.btn_test_sel.setToolTip("Test selected rows only")

        self.btn_scrape.clicked.connect(self._start_scrape)
        self.btn_sources.clicked.connect(self._show_sources)
        self.btn_test.clicked.connect(self._start_test_all)
        self.btn_test_sel.clicked.connect(self._start_test_selected)
        self.btn_stop.clicked.connect(self._stop_all)
        self.btn_clear.clicked.connect(self._clear_table)

        for b in (self.btn_scrape, self.btn_sources, self.btn_test, self.btn_test_sel,
                  self.btn_stop, self.btn_clear):
            lay.addWidget(b)
        lay.addWidget(_vsep())

        lay.addWidget(QLabel("Filter:"))
        self.filter_edit = QLineEdit()
        self.filter_edit.setPlaceholderText("ip / port / source …")
        self.filter_edit.setFixedWidth(200)
        self.filter_edit.textChanged.connect(self._apply_filter)
        lay.addWidget(self.filter_edit)
        lay.addStretch()

        lay.addWidget(QLabel("Threads:"))
        self.thread_spin = QSpinBox()
        self.thread_spin.setRange(5,200); self.thread_spin.setValue(50)
        self.thread_spin.setFixedWidth(64)
        lay.addWidget(self.thread_spin)
        lay.addWidget(_vsep())

        bc = _btn("💾 CSV", "#1a3a1a", 90)
        bt = _btn("💾 TXT", "#1a3a1a", 90)
        bc.clicked.connect(lambda: self._export("csv"))
        bt.clicked.connect(lambda: self._export("txt"))
        lay.addWidget(bc); lay.addWidget(bt)
        return w

    def _mk_table(self):
        self.table = QTableWidget()
        self.table.setColumnCount(NUM_COLS)
        self.table.setHorizontalHeaderLabels(COL_HEADERS)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setSortingEnabled(False)   # re-enabled after scrape
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setDefaultSectionSize(24)
        h = self.table.horizontalHeader()
        for col, mode in [
            (COL_IP,      QHeaderView.ResizeMode.ResizeToContents),
            (COL_PORT,    QHeaderView.ResizeMode.ResizeToContents),
            (COL_COUNTRY, QHeaderView.ResizeMode.ResizeToContents),
            (COL_SOURCE,  QHeaderView.ResizeMode.ResizeToContents),
            (COL_STATUS,  QHeaderView.ResizeMode.Stretch),
            (COL_LATENCY, QHeaderView.ResizeMode.ResizeToContents),
        ]:
            h.setSectionResizeMode(col, mode)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._ctx_menu)
        return self.table

    def _mk_log(self):
        w = QWidget()
        lay = QVBoxLayout(w); lay.setContentsMargins(0,0,0,0); lay.setSpacing(0)
        hdr = QWidget(); hdr.setFixedHeight(24)
        hdr.setStyleSheet(f"background:{BG_PANEL}; border-top:1px solid {BORDER};")
        hl = QHBoxLayout(hdr); hl.setContentsMargins(10,0,10,0)
        lbl = QLabel("Console Log"); lbl.setStyleSheet(f"color:{TEXT_SEC}; font-size:10px;")
        hl.addWidget(lbl); hl.addStretch()
        clr = QPushButton("Clear")
        clr.setFixedSize(50,18)
        clr.setStyleSheet(f"background:#2a2a2a; color:{TEXT_SEC}; border:none; font-size:9px; border-radius:2px;")
        clr.clicked.connect(lambda: self.log_box.clear())
        hl.addWidget(clr); lay.addWidget(hdr)
        self.log_box = QPlainTextEdit()
        self.log_box.setReadOnly(True); self.log_box.setMaximumBlockCount(2000)
        lay.addWidget(self.log_box); return w

    def _mk_progress(self):
        w = QWidget(); w.setFixedHeight(26)
        w.setStyleSheet(f"background:{BG_DARK};")
        lay = QHBoxLayout(w); lay.setContentsMargins(12,4,12,4)
        self.progress = QProgressBar(); self.progress.setValue(0)
        self.progress.setFixedHeight(16)
        lay.addWidget(self.progress); return w

    def _mk_statusbar(self):
        w = QWidget(); w.setFixedHeight(26)
        w.setStyleSheet(f"background:{BG_PANEL}; border-top:1px solid {BORDER};")
        lay = QHBoxLayout(w); lay.setContentsMargins(12,0,12,0); lay.setSpacing(8)
        self.lbl_status = QLabel("Ready")
        self.lbl_total  = QLabel("Total: 0")
        self.lbl_up     = QLabel("Up: 0")
        self.lbl_down   = QLabel("Down: 0")
        self.lbl_status.setStyleSheet(f"color:{TEXT_SEC};")
        self.lbl_up.setStyleSheet(f"color:{CLR_UP};")
        self.lbl_down.setStyleSheet(f"color:{CLR_DOWN};")
        for lbl in (self.lbl_status, self.lbl_total, self.lbl_up, self.lbl_down):
            lay.addWidget(lbl)
            if lbl is not self.lbl_down: lay.addWidget(_vsep())
        lay.addStretch()
        ver = QLabel(f"v{VERSION}"); ver.setStyleSheet(f"color:{TEXT_SEC};")
        lay.addWidget(ver); return w

    def _build_menu(self):
        mb = self.menuBar()
        fm = mb.addMenu("File")
        fm.addAction("Export CSV", lambda: self._export("csv"))
        fm.addAction("Export TXT", lambda: self._export("txt"))
        fm.addSeparator(); fm.addAction("Quit", self.close)
        pm = mb.addMenu("Proxies")
        pm.addAction("Scrape All Sources",    self._start_scrape)
        pm.addAction("Test All Proxies",      self._start_test_all)
        pm.addAction("Test Selected Proxies", self._start_test_selected)
        pm.addSeparator()
        pm.addAction("Remove Dead Proxies",   self._remove_dead)
        pm.addAction("Clear List",            self._clear_table)
        hm = mb.addMenu("Help")
        hm.addAction("About", self._show_about)

    # ── table helpers ─────────────────────────────────────────────────────────

    def _cell(self, text, color=None):
        item = QTableWidgetItem(text)
        item.setTextAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        if color: item.setForeground(QBrush(QColor(color)))
        return item

    def _add_proxy_row(self, ip, port, country, source):
        key = f"{ip}:{port}"
        if key in self._row_map: return
        row = self.table.rowCount()
        self.table.insertRow(row)
        self._row_map[key] = row
        self.table.setItem(row, COL_IP,      self._cell(ip))
        self.table.setItem(row, COL_PORT,    self._cell(port))
        self.table.setItem(row, COL_COUNTRY, self._cell(country or "—"))
        self.table.setItem(row, COL_SOURCE,  self._cell(source, TEXT_SEC))
        self.table.setItem(row, COL_STATUS,  self._cell("Untested", CLR_UNKWN))
        self.table.setItem(row, COL_LATENCY, self._cell("—"))
        # O(1) — just update the total label; up/down counters unchanged
        self.lbl_total.setText(f"Total: {self.table.rowCount():,}")

    def _queue_result(self, ip, port, ok, ms):
        """Called from TesterWorker signal — just enqueue, never touch the table here."""
        self._result_queue.append((ip, port, ok, ms))
        if ok: self._cnt_up   += 1
        else:  self._cnt_down += 1

    def _flush_results(self):
        """Drain the queue and write to table in one batched repaint."""
        if not self._result_queue:
            return
        batch, self._result_queue = self._result_queue, []
        self.table.setUpdatesEnabled(False)
        for ip, port, ok, ms in batch:
            row = self._row_map.get(f"{ip}:{port}")
            if row is None: continue
            s = self._cell("Up" if ok else "Down", CLR_UP if ok else CLR_DOWN)
            l = QTableWidgetItem(str(ms) if ok else "—")
            l.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            if ok: l.setForeground(QBrush(QColor(CLR_UP)))
            self.table.setItem(row, COL_STATUS,  s)
            self.table.setItem(row, COL_LATENCY, l)
        self.table.setUpdatesEnabled(True)
        self._update_counts()

    def _update_counts(self):
        """O(1) — reads pre-maintained counters."""
        self.lbl_total.setText(f"Total: {self.table.rowCount():,}")
        self.lbl_up.setText(f"Up: {self._cnt_up:,}")
        self.lbl_down.setText(f"Down: {self._cnt_down:,}")

    def _apply_filter(self, text):
        text = text.lower()
        for row in range(self.table.rowCount()):
            vis = any(text in (self.table.item(row, c).text().lower()
                                if self.table.item(row, c) else "")
                      for c in range(NUM_COLS))
            self.table.setRowHidden(row, not vis)

    def _rebuild_row_map(self):
        self._row_map = {}
        for r in range(self.table.rowCount()):
            ip = self.table.item(r, COL_IP)
            pt = self.table.item(r, COL_PORT)
            if ip and pt: self._row_map[f"{ip.text()}:{pt.text()}"] = r

    # ── context menu ──────────────────────────────────────────────────────────

    def _ctx_menu(self, pos):
        if not self.table.selectedItems(): return
        m = QMenu(self)
        m.addAction("⚡ Test Selected",   self._start_test_selected)
        m.addSeparator()
        m.addAction("📋 Copy IP:Port",    self._copy_selected)
        m.addSeparator()
        m.addAction("✕  Remove Selected", self._remove_selected)
        m.exec(self.table.viewport().mapToGlobal(pos))

    def _copy_selected(self):
        rows  = sorted(set(i.row() for i in self.table.selectedItems()))
        lines = [f"{self.table.item(r,COL_IP).text()}:{self.table.item(r,COL_PORT).text()}"
                 for r in rows if self.table.item(r,COL_IP) and self.table.item(r,COL_PORT)]
        if lines:
            QApplication.clipboard().setText("\n".join(lines))
            self._status(f"Copied {len(lines)} proxies.")

    def _remove_selected(self):
        rows = sorted(set(i.row() for i in self.table.selectedItems()), reverse=True)
        for r in rows:
            ip = self.table.item(r, COL_IP); pt = self.table.item(r, COL_PORT)
            if ip and pt: self._row_map.pop(f"{ip.text()}:{pt.text()}", None)
            status = self.table.item(r, COL_STATUS)
            if status:
                if status.text() == "Up":   self._cnt_up   = max(0, self._cnt_up   - 1)
                if status.text() == "Down": self._cnt_down = max(0, self._cnt_down - 1)
            self.table.removeRow(r)
        self._rebuild_row_map(); self._update_counts()

    def _remove_dead(self):
        dead = [r for r in range(self.table.rowCount())
                if self.table.item(r, COL_STATUS) and
                self.table.item(r, COL_STATUS).text() == "Down"]
        for r in sorted(dead, reverse=True):
            ip = self.table.item(r, COL_IP); pt = self.table.item(r, COL_PORT)
            if ip and pt: self._row_map.pop(f"{ip.text()}:{pt.text()}", None)
            self.table.removeRow(r)
        self._cnt_down = 0
        self._rebuild_row_map(); self._update_counts()
        self._status(f"Removed {len(dead)} dead proxies.")

    def _clear_table(self):
        self.table.setSortingEnabled(False)
        self.table.setRowCount(0); self._row_map.clear()
        self._cnt_up = 0; self._cnt_down = 0
        self._result_queue.clear()
        self._update_counts(); self.progress.setValue(0)
        self._status("List cleared.")

    # ── scraping ──────────────────────────────────────────────────────────────

    def _start_scrape(self):
        if self._scraper and self._scraper.isRunning(): return
        active = [s for s in SOURCES if s["name"] in self._enabled_sources]
        if not active:
            self._status("No sources selected — click ⚙ SOURCES to choose."); return
        self._running(True)
        self.progress.setValue(0); self.progress.setMaximum(len(active))
        self._src_done = 0
        self._log(f"Starting scrape — {len(active)}/{len(SOURCES)} sources …")
        self._status("Scraping …")

        self._scraper = ScraperWorker(active, self)
        self._scraper.proxy_found.connect(self._add_proxy_row)
        self._scraper.source_done.connect(self._on_src_done)
        self._scraper.log.connect(self._log)
        self._scraper.finished_all.connect(self._on_scrape_done)
        self._scraper.start()

    def _on_src_done(self, name, count):
        self._src_done += 1
        self.progress.setValue(self._src_done)
        self._status(f"[{name}] {count} proxies  —  total: {self.table.rowCount():,}")

    def _on_scrape_done(self, total):
        self._running(False)
        self.progress.setValue(self.progress.maximum())
        self.table.setSortingEnabled(True)
        msg = f"Scrape complete — {total:,} unique proxies."
        self._status(msg); self._log(msg)

    # ── testing ───────────────────────────────────────────────────────────────

    def _proxies_all(self):
        return [(self.table.item(r,COL_IP).text(), self.table.item(r,COL_PORT).text())
                for r in range(self.table.rowCount())
                if self.table.item(r,COL_IP) and self.table.item(r,COL_PORT)]

    def _proxies_sel(self):
        rows = set(i.row() for i in self.table.selectedItems())
        return [(self.table.item(r,COL_IP).text(), self.table.item(r,COL_PORT).text())
                for r in rows if self.table.item(r,COL_IP) and self.table.item(r,COL_PORT)]

    def _start_test(self, proxies):
        if not proxies: self._status("No proxies to test."); return
        if self._tester and self._tester.isRunning(): return
        self._rebuild_row_map()
        for ip, port in proxies:
            row = self._row_map.get(f"{ip}:{port}")
            if row is not None:
                item = QTableWidgetItem("Testing …")
                item.setForeground(QBrush(QColor(CLR_TEST)))
                self.table.setItem(row, COL_STATUS, item)
        self._cnt_up = 0; self._cnt_down = 0   # reset for this test run
        self._result_queue.clear()
        self._running(True)
        self.progress.setValue(0); self.progress.setMaximum(len(proxies))
        self._log(f"Testing {len(proxies):,} proxies with {self.thread_spin.value()} threads …")
        self._status(f"Testing {len(proxies):,} proxies …")

        self._tester = TesterWorker(proxies, self.thread_spin.value(), self)
        self._tester.result.connect(self._queue_result)
        self._tester.progress.connect(lambda d, t: self.progress.setValue(d))
        self._tester.finished.connect(self._on_test_done)
        self._flush_timer.start()
        self._tester.start()

    def _start_test_all(self):      self._start_test(self._proxies_all())
    def _start_test_selected(self): self._start_test(self._proxies_sel())

    def _on_test_done(self):
        self._flush_timer.stop()
        self._flush_results()          # drain any remaining queued results
        self._running(False)
        self.progress.setValue(self.progress.maximum())
        self._update_counts()
        msg = f"Testing complete — Up: {self._cnt_up:,}  Down: {self._cnt_down:,}"
        self._status(msg); self._log(msg)

    # ── stop ──────────────────────────────────────────────────────────────────

    def _stop_all(self):
        if self._scraper and self._scraper.isRunning(): self._scraper.stop()
        if self._tester  and self._tester.isRunning():  self._tester.stop()
        self._flush_timer.stop()
        self._flush_results()
        self._running(False); self._status("Stopped.")

    # ── export ────────────────────────────────────────────────────────────────

    def _export(self, fmt):
        total = self.table.rowCount()
        if total == 0:
            QMessageBox.information(self, APP_NAME, "Nothing to export."); return
        ext  = "CSV Files (*.csv)" if fmt == "csv" else "Text Files (*.txt)"
        path, _ = QFileDialog.getSaveFileName(
            self, "Save", f"socks5_{datetime.now():%Y%m%d_%H%M%S}.{fmt}", ext)
        if not path: return
        try:
            with open(path, "w", newline="", encoding="utf-8") as fh:
                if fmt == "csv":
                    w = csv.writer(fh); w.writerow(COL_HEADERS)
                    for r in range(total):
                        w.writerow([(self.table.item(r,c).text()
                                     if self.table.item(r,c) else "")
                                    for c in range(NUM_COLS)])
                else:
                    for r in range(total):
                        ip = self.table.item(r,COL_IP)
                        pt = self.table.item(r,COL_PORT)
                        if ip and pt: fh.write(f"{ip.text()}:{pt.text()}\n")
            self._status(f"Exported {total:,} proxies → {path}")
        except Exception as e:
            QMessageBox.critical(self, "Export Failed", str(e))

    # ── misc ──────────────────────────────────────────────────────────────────

    def _log(self, text):    self.log_box.appendPlainText(text)
    def _status(self, text): self.lbl_status.setText(text)

    def _running(self, yes):
        self.btn_scrape.setEnabled(not yes)
        self.btn_test.setEnabled(not yes)
        self.btn_test_sel.setEnabled(not yes)
        self.btn_stop.setEnabled(yes)

    def _show_sources(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Select Sources to Scrape")
        dlg.setWindowIcon(load_app_icon())
        dlg.setMinimumWidth(360)
        dlg.setStyleSheet(f"""
            QDialog    {{ background:{BG_PANEL}; color:{TEXT_PRI};
                          font-family:'Courier New',Courier,monospace; }}
            QCheckBox  {{ color:{TEXT_PRI}; font-size:11px; padding:4px; }}
            QCheckBox::indicator {{ width:14px; height:14px;
                                    border:1px solid {BORDER}; background:{BG_TABLE};
                                    border-radius:2px; }}
            QCheckBox::indicator:checked {{ background:{ACCENT}; border-color:{ACCENT}; }}
            QPushButton {{ background:{ACCENT}; color:#fff; border:none;
                           border-radius:4px; padding:6px 18px; font-size:11px; }}
            QPushButton:hover {{ background:{ACCENT_HOV}; }}
            QLabel {{ color:{TEXT_SEC}; font-size:10px; }}
        """)

        outer = QVBoxLayout(dlg); outer.setContentsMargins(16,16,16,16); outer.setSpacing(10)
        outer.addWidget(QLabel("Check the sources you want to include in the next scrape:"))

        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setStyleSheet(f"border:1px solid {BORDER}; background:{BG_TABLE};")
        inner = QWidget()
        vbox  = QVBoxLayout(inner); vbox.setContentsMargins(8,8,8,8); vbox.setSpacing(2)

        checks: dict[str, QCheckBox] = {}
        for src in SOURCES:
            cb = QCheckBox(src["name"])
            cb.setChecked(src["name"] in self._enabled_sources)
            vbox.addWidget(cb)
            checks[src["name"]] = cb
        vbox.addStretch()
        scroll.setWidget(inner)
        outer.addWidget(scroll)

        # Select all / none buttons
        row = QHBoxLayout()
        all_btn  = QPushButton("All");  all_btn.setFixedHeight(26)
        none_btn = QPushButton("None"); none_btn.setFixedHeight(26)
        all_btn.setStyleSheet(f"background:#2a2a2a; color:{TEXT_PRI}; border:none; border-radius:3px; padding:2px 12px;")
        none_btn.setStyleSheet(all_btn.styleSheet())
        all_btn.clicked.connect(lambda:  [cb.setChecked(True)  for cb in checks.values()])
        none_btn.clicked.connect(lambda: [cb.setChecked(False) for cb in checks.values()])
        row.addWidget(all_btn); row.addWidget(none_btn); row.addStretch()
        outer.addLayout(row)

        bbox = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                                QDialogButtonBox.StandardButton.Cancel)
        bbox.setStyleSheet(f"QPushButton {{ background:{ACCENT}; color:#fff; border:none; border-radius:4px; padding:5px 16px; }}"
                           f"QPushButton:hover {{ background:{ACCENT_HOV}; }}")
        bbox.accepted.connect(dlg.accept); bbox.rejected.connect(dlg.reject)
        outer.addWidget(bbox)

        if dlg.exec() == QDialog.DialogCode.Accepted:
            self._enabled_sources = {name for name, cb in checks.items() if cb.isChecked()}
            n = len(self._enabled_sources)
            self._status(f"{n} source{'s' if n != 1 else ''} selected.")
            self.btn_sources.setText(f"⚙ SOURCES ({n})")

    def _show_about(self):
        QMessageBox.about(self, f"About {APP_NAME}",
            f"<b style='font-family:Courier;'>{APP_NAME}</b><br>"
            f"<span style='font-family:Courier;'>{ORG_NAME}  v{VERSION}</span><br><br>"
            f"<span style='font-family:Courier;font-size:small;'>"
            f"Scrapes {len(SOURCES)} public SOCKS5 proxy sources.<br>"
            f"Tests with a real SOCKS5 handshake (no extra libs needed).</span>")

    def closeEvent(self, event):
        self._stop_all(); super().closeEvent(event)


# ─────────────────────────────────────────────────────────────────────────────
#  Entry point
# ─────────────────────────────────────────────────────────────────────────────

def main():
    _fix_sudo_display()
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    app.setWindowIcon(load_app_icon())

    splash = create_splash()
    if splash:
        splash.show()
        for msg in ["Initializing …",
                    "Loading proxy sources …",
                    "Preparing network engine …",
                    "Ready to hunt proxies …"]:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255),
            )
            app.processEvents()
            time.sleep(0.4)

    win = MainWindow()
    win.show()
    if splash: splash.finish(win)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
